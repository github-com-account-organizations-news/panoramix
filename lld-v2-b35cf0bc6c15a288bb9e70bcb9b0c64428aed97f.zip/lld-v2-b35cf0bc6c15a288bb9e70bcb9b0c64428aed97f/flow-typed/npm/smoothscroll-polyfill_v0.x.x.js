// flow-typed signature: f47eadb528a84826d1293806214f5638
// flow-typed version: c6154227d1/smoothscroll-polyfill_v0.x.x/flow_>=v0.104.x

declare module 'smoothscroll-polyfill' {
  declare module.exports: { polyfill: () => void, ... }
}
