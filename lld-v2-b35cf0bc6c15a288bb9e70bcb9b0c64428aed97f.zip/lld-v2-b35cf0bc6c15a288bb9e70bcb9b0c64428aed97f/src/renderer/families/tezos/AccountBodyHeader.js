// @flow

import Delegation from "./Delegation";

export default Delegation;
