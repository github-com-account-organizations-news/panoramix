---
name: "\U0001F5E3 Start a Discussion"
about: Discuss changes to improve the state of Ledger Live. Please keep one issue
  per topic.
title: ''
labels: ''
assignees: ''

---

<!-- DESCRIPTION: Explain precisely what you think should be improved and how you think it should work -->
<!-- One topic at a time, use more issues if needed -->


#### Ledger Live Version

<!-- Precise your current app version (Settings > About or bottom-left corner on a crash screen) -->

- Ledger Live **version_here**

#### Part of the application to improve

<!-- which part is to improve? e.g. Send > Step 1 -->
