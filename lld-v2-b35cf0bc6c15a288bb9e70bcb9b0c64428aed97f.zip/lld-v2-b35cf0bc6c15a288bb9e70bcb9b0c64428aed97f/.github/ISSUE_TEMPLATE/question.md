---
name: "\U0001F4AC Question"
about: If you need help using the app, please contact the support at https://support.ledgerwallet.com/
title: ''
labels: ''
assignees: ''

---

<!-- https://support.ledgerwallet.com/ – Please prefer using the support for app usage questions, Github issues are only for technical / developer usage -->
