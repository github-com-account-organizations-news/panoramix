// @flow

declare module 'redux-actions' {
  declare module.exports: any
}
