// @flow

declare module 'winston' {
  declare module.exports: any
}
