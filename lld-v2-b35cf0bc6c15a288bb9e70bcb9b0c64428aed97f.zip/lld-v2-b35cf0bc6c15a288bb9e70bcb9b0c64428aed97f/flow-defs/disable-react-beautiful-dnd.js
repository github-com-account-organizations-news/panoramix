// @flow

declare module "react-beautiful-dnd" {
  declare module.exports: any;
}
