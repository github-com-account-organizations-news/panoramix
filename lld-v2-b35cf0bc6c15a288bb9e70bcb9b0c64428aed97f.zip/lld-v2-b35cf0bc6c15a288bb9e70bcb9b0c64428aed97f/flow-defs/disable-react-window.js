// @flow

declare module "react-window" {
  declare module.exports: any;
}
