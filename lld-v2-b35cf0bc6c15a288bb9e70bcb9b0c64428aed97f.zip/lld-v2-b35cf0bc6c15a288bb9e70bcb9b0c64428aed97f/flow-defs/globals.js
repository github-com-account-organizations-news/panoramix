// @flow

declare var INDEX_URL: string
declare var __DEV__: boolean
declare var __TEST__: boolean
declare var __ENV__: string
declare var __PRINT_MODE__: string
declare var __SENTRY_URL__: string
declare var __GIT_REVISION__: string
declare var __APP_VERSION__: string
declare var __static: string
declare var describe: Function
declare var test: Function
declare var it: Function
declare var expect: Function

declare var ResizeObserver: Class<any>
